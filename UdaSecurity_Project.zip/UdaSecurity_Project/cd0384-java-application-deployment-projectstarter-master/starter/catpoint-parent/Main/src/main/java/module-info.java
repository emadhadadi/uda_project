module Main {
    requires com.miglayout.swing;
    requires security;
    requires java.desktop;
    requires image;
}