package imageservice;

import java.awt.image.BufferedImage;

public interface ImageInterface {



    boolean imageContainsCat(BufferedImage image, float confidenceThreshhold);
}
