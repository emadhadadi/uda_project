package services;

import data.*;
import imageservice.ImageInterface;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {




    private  SecurityService securityService;



    @Mock
    private ImageInterface imageService;



    @Mock
    private SecurityRepository securityRepository;


    private Sensor sensor;

    Sensor CreateSensor(){
        String name = UUID.randomUUID().toString();
        return   new Sensor(name,SensorType.WINDOW);

    }


    public SecurityServiceTest(SecurityRepository securityRepository, ImageInterface imageService) {
        this.securityRepository = securityRepository;
        this.imageService = imageService;
    }

    @BeforeEach
    void  init(){
        sensor=CreateSensor();
        securityService = new SecurityService(securityRepository,imageService);

    }



    // 1

    @Test
    void IfAlarmArmedAndSensorBecomesActivated_PutTheSystemIntoPending(){

        if(securityService.getArmingStatus().equals(ArmingStatus.ARMED_AWAY) || securityService.getArmingStatus().equals(ArmingStatus.ARMED_HOME)){
            if(securityService.getAlarmStatus().equals(AlarmStatus.NO_ALARM)){
                securityService.changeSensorActivationStatus(sensor,true);
            }
        }
        assertEquals(AlarmStatus.PENDING_ALARM,securityService.getAlarmStatus());
    }




/*


   // 2
   @Test
   void IfAlarmArmedAndSensorBecomesActivated_PutTheSystemIntoAlarm(){
        if(securityService.getArmingStatus().equals(ArmingStatus.ARMED_HOME) || securityService.getArmingStatus().equals(ArmingStatus.ARMED_AWAY)){
            if(securityService.getAlarmStatus().equals(AlarmStatus.PENDING_ALARM)){
                sensor.setActive(true);
                securityService.changeSensorActivationStatus(sensor,true);
            }
        }
        assertEquals(AlarmStatus.ALARM,securityService.getAlarmStatus());
   }


*/

    @Test
    void addStatusListener() {
    }

    @Test
    void removeStatusListener() {
    }

    @Test
    void changeSensorActivationStatus() {
    }

    @Test
    void addSensor() {
    }

    @Test
    void removeSensor() {
    }
}