module security {
    requires java.desktop;
    requires image;
    requires com.google.gson;
    requires java.prefs;
    requires com.google.common;
    exports data;

    opens data to com.google.gson;
    exports services;
    exports app;
}