module security.service {
    requires java.datatransfer;
    requires java.desktop;
    requires java.prefs;
    requires com.google.gson;
    requires com.google.common;
    requires image.service;
    exports data;
    exports service;
    exports application;

    opens data to com.google.gson;
}