package service;


import application.StatusListener;
import data.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import serviceImage.ImageInterface;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
public class TestSecurityService {





    private  SecurityService securityService;



    private final SensorType sensorType=SensorType.WINDOW;

    @Mock
    private ImageInterface imageService;

    private String name = UUID.randomUUID().toString();

    @Mock
    private SecurityRepository securityRepository;

    @Mock
    private StatusListener statusListener;



    private Sensor sensor;

    Sensor CreateSensor(){
      return   new Sensor(name,SensorType.WINDOW);

    }


    public TestSecurityService(SecurityRepository securityRepository, ImageInterface imageService) {
        this.securityRepository = securityRepository;
        this.imageService = imageService;
    }

    @BeforeEach
    void  init(){
        sensor=CreateSensor();
        securityService = new SecurityService(securityRepository,imageService);

    }



    // 1
    @Test
    void IfAlarmArmedAndSensorBecomesActivated_PutTheSystemIntoPending(){

        if(securityService.getArmingStatus().equals(ArmingStatus.ARMED_AWAY) || securityService.getArmingStatus().equals(ArmingStatus.ARMED_HOME)){
            if(securityService.getAlarmStatus().equals(AlarmStatus.NO_ALARM)){
                securityService.changeSensorActivationStatus(sensor,true);
            }
        }
        assertEquals(AlarmStatus.PENDING_ALARM,securityService.getAlarmStatus());
    }



/*


   // 2
   @Test
   void IfAlarmArmedAndSensorBecomesActivated_PutTheSystemIntoAlarm(){
        if(securityService.getArmingStatus().equals(ArmingStatus.ARMED_HOME) || securityService.getArmingStatus().equals(ArmingStatus.ARMED_AWAY)){
            if(securityService.getAlarmStatus().equals(AlarmStatus.PENDING_ALARM)){
                sensor.setActive(true);
                securityService.changeSensorActivationStatus(sensor,true);
            }
        }
        assertEquals(AlarmStatus.ALARM,securityService.getAlarmStatus());
   }


   // 2

    @Test
    void IfPendingAlarmAndAllSensorsInactive_ReturnNoAlarmState(){

                 if (securityService.getAlarmStatus().equals(AlarmStatus.PENDING_ALARM) && sensor.getActive().equals(true)) {
                     securityService.setAlarmStatus(AlarmStatus.NO_ALARM);
                 }


       assertEquals(AlarmStatus.NO_ALARM,securityService.getAlarmStatus());
    }



    // 4

    @Test
    void IfAlarmIsActive_ChangeSensorStateShouldNotAffectTheAlarmState(){

          if(securityService.getArmingStatus().equals(ArmingStatus.ARMED_HOME) || securityService.getArmingStatus().equals(ArmingStatus.ARMED_AWAY)){

              if(securityService.getAlarmStatus().equals(AlarmStatus.ALARM) || sensor.getActive().equals(true)){
                     sensor.setActive(false);
                      securityService.changeSensorActivationStatus(sensor, false);
                  }

          }
          assertEquals(AlarmStatus.ALARM,securityService.getAlarmStatus());

    }




    // 5

    @Test
    void IfSensorIsActivatedWhileAlreadyActiveAndSystemIsInPendingState_ChangeItToAlarmState(){

            if (securityService.getAlarmStatus().equals(AlarmStatus.PENDING_ALARM) &&sensor.getActive().equals(true)){
                sensor.setActive(true);
                securityService.changeSensorActivationStatus(sensor,true);
            }

        assertEquals(AlarmStatus.ALARM,securityService.getAlarmStatus());
    }


    // 6
    @Test
    void IfSensorIsDeactivatedWhileAlreadyInactive_MakeNoChangesToTheAlarmState(){

            if (sensor.getActive().equals(false)){
                securityService.changeSensorActivationStatus(sensor,true);
                sensor.setActive(true);
            }
            assertTrue(sensor.getActive());
    }


    // 7
     @Test
    void IfImageServiceIdentifiesImageContainingCatWhileSystemIsArmedHome_PutSystemInToAlarmStatus(){
        if(imageService.imageContainsCat(null, 90.0f)){
            securityService.setAlarmStatus(AlarmStatus.ALARM);
        }
        assertEquals(AlarmStatus.ALARM,securityService.getAlarmStatus());

    }


    // 8

    @Test
    void IfImageServiceIdentifiesImageContainingDoesNotCatWhileSystemIsArmedHome_PutSystemInToNOAlarmStatusAndSensorsToNotActive(){
        if(!imageService.imageContainsCat(null, 90.0f)){
            securityService.setAlarmStatus(AlarmStatus.NO_ALARM);
            securityService.changeSensorActivationStatus(sensor,false);
        }
    }


    // 9

    @Test
    void IfSystemIsDisarmed_SetStatusToNoAlarm(){
        if(securityService.getArmingStatus().equals(ArmingStatus.DISARMED)){
            securityService.setAlarmStatus(AlarmStatus.NO_ALARM);
        }
        assertEquals(AlarmStatus.NO_ALARM,securityService.getAlarmStatus());
    }

    // 10
    @Test
    void IfSystemIsArmed_ResetAllSensorsToInactive(){
        if(securityService.getArmingStatus().equals(ArmingStatus.ARMED_HOME)|| securityService.getArmingStatus().equals(ArmingStatus.ARMED_AWAY)){
            for(Sensor sr:securityService.getSensors()) {
                securityService.changeSensorActivationStatus(sr, false);
                assertEquals(false,sr.getActive());
            }
        }


    }
*/















}
