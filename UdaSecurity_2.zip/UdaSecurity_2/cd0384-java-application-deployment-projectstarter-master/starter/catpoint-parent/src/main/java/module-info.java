module catpoint.parent {
    requires com.miglayout.swing;
    requires java.desktop;

    requires security.service;
    requires image.service;


}